var XmanFactory = artifacts.require("./XmanFactory.sol");

module.exports = function(deployer) {
  deployer.deploy(XmanFactory);
};